export const actions = {
    SET_FILE: "SET_FILE",
    SET_CURRENT_PATH: "SET_CURRENT_PATH",
};
