export const typesName = {
    file: "file",
    folder: "folder",
    svg: "svg",
    js: "js",
    ts: "ts",
    img: "img",
};

export const popoverChilds = ["Copy", "Delete", "Rename"];
